Opencart installation steps:
- copy content of upload folder merge it in your opencart upload folder
- login as admin
- go to Extensions->Payments
- Install Easebuzz gateway
- Click on Edit Easebuzz
- Enter key/salt and enable it.

